import re


def _last_user_text(callback_context) -> str:
    try:
        parts = callback_context.get_last_user_input() or []
    except Exception:
        content = getattr(callback_context, "user_content", None)
        parts = getattr(content, "parts", None) or []

    values = []
    for part in parts:
        text = getattr(part, "text", None)
        if text:
            values.append(str(text))
    return " ".join(values).strip()


def _claim_id(text: str) -> str:
    match = re.search(r"\bCLM\s*[- ]?\s*(\d{4,})\b", text or "", re.IGNORECASE)
    return f"CLM{match.group(1)}".upper() if match else ""


def _answer(text: str) -> str:
    return re.sub(r"[^a-z0-9 ]+", " ", (text or "").lower()).strip()


def _is_yes(text: str) -> bool:
    value = _answer(text)
    return value in {
        "yes", "yes please", "yeah", "yep", "sure", "correct",
        "confirm", "confirmed", "proceed", "go ahead", "do it"
    }


def _is_no(text: str) -> bool:
    value = _answer(text)
    return value in {
        "no", "nope", "do not", "dont", "don t", "stop",
        "do not proceed", "dont proceed", "don t proceed", "not now"
    }


def _clear(callback_context) -> None:
    callback_context.variables["cancel_confirmation_pending"] = False
    callback_context.variables["cancel_confirmation_granted"] = False
    callback_context.variables["pending_cancel_claim_id"] = ""
    callback_context.variables["cancel_in_progress"] = False


def _confirmation(claim_id: str):
    return LlmResponse.from_parts(parts=[
        Part.from_text(
            text=f"To confirm, you'd like to cancel claim {claim_id}. Should I proceed?"
        )
    ])


def before_model_callback(callback_context, llm_request):
    """Enforces a confirmation turn before the destructive cancel-claim tool call."""
    user_text = _last_user_text(callback_context)
    supplied_claim_id = _claim_id(user_text)
    requested_intent = str(
        callback_context.variables.get("requested_intent", "") or ""
    ).lower()

    pending = bool(
        callback_context.variables.get("cancel_confirmation_pending", False)
    )
    pending_claim_id = str(
        callback_context.variables.get("pending_cancel_claim_id", "") or ""
    ).upper()

    if pending and pending_claim_id:
        if supplied_claim_id and supplied_claim_id != pending_claim_id:
            callback_context.variables["claim_id"] = supplied_claim_id
            callback_context.variables["pending_cancel_claim_id"] = supplied_claim_id
            callback_context.variables["cancel_confirmation_granted"] = False
            return _confirmation(supplied_claim_id)

        if _is_yes(user_text):
            callback_context.variables["cancel_confirmation_granted"] = True
            callback_context.variables["cancel_in_progress"] = True
            return LlmResponse.from_parts(parts=[
                Part.from_function_call(
                    name="cancel_claim_cancel_claim",
                    args={"claim_id": pending_claim_id}
                )
            ])

        if _is_no(user_text):
            declined_claim_id = pending_claim_id
            _clear(callback_context)
            return LlmResponse.from_parts(parts=[
                Part.from_text(
                    text=(
                        f"Okay, I won't cancel claim {declined_claim_id}. "
                        "Is there anything else about your claims I can help with?"
                    )
                )
            ])

        return LlmResponse.from_parts(parts=[
            Part.from_text(
                text=f"Please answer yes or no. Should I cancel claim {pending_claim_id}?"
            )
        ])

    if requested_intent == "claim_deletion" and supplied_claim_id:
        callback_context.variables["claim_id"] = supplied_claim_id
        callback_context.variables["pending_cancel_claim_id"] = supplied_claim_id
        callback_context.variables["cancel_confirmation_pending"] = True
        callback_context.variables["cancel_confirmation_granted"] = False
        callback_context.variables["cancel_in_progress"] = False
        return _confirmation(supplied_claim_id)

    return None
