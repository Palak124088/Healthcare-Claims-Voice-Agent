def _normalize(value) -> str:
    return str(value or "").strip().upper().replace(" ", "")


def before_tool_callback(tool, args, tool_context):
    """Blocks any cancel-claim call that was not explicitly confirmed."""
    tool_name = str(getattr(tool, "name", "") or "")

    if tool_name == "update_claim_state":
        if tool_context.variables.get("cancel_confirmation_pending", False):
            return {
                "skipped": True,
                "code": "CANCEL_CONFIRMATION_ACTIVE",
                "message": "Do not update retry state while cancellation confirmation is pending."
            }
        if args.get("increment_claim_attempts") and not tool_context.variables.get(
            "last_claim_failed", False
        ):
            return {
                "skipped": True,
                "reason": "Previous claim action succeeded; not counting as a failure."
            }
        return None

    if tool_name not in ("cancel_claim_cancel_claim", "cancel_claim"):
        return None

    requested_claim_id = _normalize(args.get("claim_id"))
    pending_claim_id = _normalize(
        tool_context.variables.get("pending_cancel_claim_id", "")
    )
    confirmed = bool(
        tool_context.variables.get("cancel_confirmation_granted", False)
    )
    in_progress = bool(tool_context.variables.get("cancel_in_progress", False))

    if in_progress and not confirmed:
        return {
            "success": False,
            "code": "DUPLICATE_CANCEL_BLOCKED",
            "message": "A cancellation request is already being processed.",
            "claim_id": requested_claim_id or pending_claim_id
        }

    if not confirmed or not pending_claim_id or requested_claim_id != pending_claim_id:
        claim_id = requested_claim_id or pending_claim_id
        if claim_id:
            tool_context.variables["claim_id"] = claim_id
            tool_context.variables["pending_cancel_claim_id"] = claim_id
        tool_context.variables["cancel_confirmation_pending"] = True
        tool_context.variables["cancel_confirmation_granted"] = False
        tool_context.variables["cancel_in_progress"] = False
        return {
            "success": False,
            "code": "CONFIRMATION_REQUIRED",
            "message": (
                f"Ask the caller: To confirm, you'd like to cancel claim "
                f"{claim_id}. Should I proceed? Do not call another claim tool."
            ),
            "claim_id": claim_id
        }

    tool_context.variables["cancel_confirmation_granted"] = False
    tool_context.variables["cancel_confirmation_pending"] = False
    tool_context.variables["cancel_in_progress"] = True
    args["claim_id"] = pending_claim_id
    return None
